from setuptools import setup, find_packages

setup(
    name="CraftWarI",
    version="1.048596",
    packages=find_packages(),
    install_requires=[
        'pygame',
        'math',
        'os'
    ]
)